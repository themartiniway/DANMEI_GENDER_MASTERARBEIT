import re
import html

# In einer txt Datei waren noch html entities vorhanden, weshalb sie hier extra umgewandelt werden
# Danach kann der Text von mir manuell gesäubert werden

# Original-Dateiname
file_path = "/Users/martinaschorsten/Desktop/" \
            "Escape the Infinite Chambers_Kapitel_Chapter 90 - Escaping from Burial Grounds (XXI).txt"

# Datei wird genommen
with open(file_path, "r", encoding="utf-8") as file:
    text = file.read()

# Umwandeln der Html-Überreste
text = html.unescape(text)

# Html-Tags werden entfernt
text = re.sub(r'<.*?>', '', text)

# Datei neu speichern (mit „_Cleaned“ kennzeichnen zur besseren Erkennung)
cleaned_file_path = file_path.replace(".txt", "_Cleaned.txt")
with open(cleaned_file_path, "w", encoding="utf-8") as file:
    file.write(text)

print(f"Gespeichert als: {cleaned_file_path}")
# Hinweis, dass der Prozess zu Ende ist
