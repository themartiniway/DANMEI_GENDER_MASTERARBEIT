import os
import zipfile
import bs4  # BeautifulSoup für HTML-Parsing
import pandas as pd
import re  # Für reguläre Ausdrücke
from fuzzywuzzy import process  # Unscharfe Textsuche verbessern

# Tabelle alle Werke einlesen
df = pd.read_excel("Tabelle alle Werke.xlsx")

# Spaltennamen richtig erkennen
print("Spalten in der Datei:", df.columns)

# Spaltennamen bereinigen (Entfernt Leerzeichen, macht auch alles klein für Einheitlichkeit)
df.columns = df.columns.str.strip()  # Entfernt unnötige Leerzeichen
df.columns = df.columns.str.lower()  # Wandelt Spaltennamen in Kleinbuchstaben um
print("Bereinigte Spaltennamen:", df.columns)

# ist "kapitelanzahl" vorhanden?
if "kapitelanzahl" not in df.columns:
    raise KeyError(
        "gibt's nicht")

# Zufällig 10 Werke auswählen, random faktor
selected_works = df.sample(n=10, random_state=42)  # random_state sorgt für gleiche Ergebnisse bei erneutem Lauf


# Funktion zur Berechnung der zu random annotierenden Kapitel
def get_annotation_chapters(total_chapters):
    if total_chapters < 4:  # Falls das Werk sehr kurz ist, einfach alle Kapitel nehmen
        return list(range(1, total_chapters + 1))

    first = max(1, round(total_chapters * 0.15))  # Kapitel aus den ersten 33%
    middle_1 = round(total_chapters * 0.45)  # Erster Punkt in der Mitte
    middle_2 = round(total_chapters * 0.55)  # Zweiter Punkt in der Mitte
    last = round(total_chapters * 0.85)  # Kapitel aus den letzten 33%

    return [first, middle_1, middle_2, last]


# Berechnung der Kapitel für jedes der 10 Werke
selected_works["zu annotierende kapitel"] = selected_works["kapitelanzahl"].apply(get_annotation_chapters)

# Ergebnisse anzeigen
print(selected_works[["name", "kapitelanzahl", "zu annotierende kapitel"]])

# Speicherung in Form einer Tabelle
selected_works.to_excel("ausgewählte_werke.xlsx", index=False)
print(" ist da als 'ausgewählte_werke.xlsx'")
