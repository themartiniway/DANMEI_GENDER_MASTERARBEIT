import pandas as pd
import random

#  Excel-Datei mit allen Werken laden
df = pd.read_excel("Tabelle alle Werke.xlsx")

# Bereinigung der Spaltennamen von Leerzeichen etc.
df.columns = df.columns.str.strip().str.lower()

# Prüfen, ob die Spalte "kapitelanzahl" vorhanden ist
# Verbeugung von Fehlermeldungen
if "kapitelanzahl" not in df.columns:
    raise KeyError("Gibt's nicht.")

#  Bereits erfolgreiche Werke mit ihren bestehenden Kapiteln sollen bleiben
erfolgreiche_werke = [
    "The Villain’s Attack Plan",
    "General, You’ve Lost Your Inhibitor!",
    "The Escort",
    "Escape the Infinite Chambers",
    "After Marrying The Villain, I Became Popular"
]


#  Liste neuer Werke, die aufgenommen werden sollen
neue_werke_liste = [
    "Aesthetic Formula",
    "BE Crazy Demon Survival System [Quick Transmigration]",
    "Black-bellied vs. Black-bellied: Ultimate Showdown",
    "Everyone Knows I’m a Good Person",
    "2013 (Doomsday)",
    "FOG [e-sports]",
    "GLORY",
    "Guide on How to Fail at Online Dating",
    "I Have Amnesia, Don’t Be Noisy",
    "I Just Want to Be in a Relationship",
    "It’s Actually Not Easy Wanting to be a Supporting Male Lead",
    "Mutated Pheromones",
    "My Underachieving Seatmate Doesn’t Need Any Comforting",
    "Online Dating Girlfriend Turn Into Brother",
    "Peerless Immortal Surrounded by Demonic Disciples",
    "PUBG Online Romance of the Century",
    "The Wife is First",
    "The Disabled Tyrant’s Pet Palm Fish [Transmigration]",
    "This Venerable One Really Didn’t Abandon My Familiar",
    "What Should I Do if the School Bully is Interested in Me",
    "Who Touched My Tail",
    "You Use a Gun, I Use a Bow [e-sports]"
]


# Bestehende erfolgreiche Werke bleiben weiterhin in der Tabelle
erhaltene_df = df[df["name"].isin(erfolgreiche_werke)]

#  Neue Werke aus der gegebenen Liste auswählen (nur falls sie in der Tabelle existieren)
neue_werke_df = df[df["name"].isin(neue_werke_liste)]

# Funktion zur random Berechnung der Kapitel für alle neuen Werke
def get_annotation_chapters(total_chapters):
    if total_chapters < 4:  # Falls das Werk sehr kurz ist, alle Kapitel nehmen
        # Sollte eigentlich nicht vorkommen, aber nur um etwaige Fehlermeldungen zu vermeiden
        return list(range(1, total_chapters + 1))

    first = max(1, round(total_chapters * 0.15))
    middle_1 = round(total_chapters * 0.45)
    middle_2 = round(total_chapters * 0.55)
    last = round(total_chapters * 0.85)

    return [first, middle_1, middle_2, last]

# die Kapitel der neuen Werke berechnen
neue_werke_df["zu annotierende kapitel"] = neue_werke_df["kapitelanzahl"].apply(get_annotation_chapters)

# Endgültige Auswahl zusammenführen in der Tabelle
finale_auswahl = pd.concat([erhaltene_df, neue_werke_df])

# Success anzeigen
print(finale_auswahl[["name", "kapitelanzahl", "zu annotierende kapitel"]])

# Speichern der Tabelle
finale_auswahl.to_excel("finale_werke.xlsx", index=False)
print("Datei gespeichert als 'finale_werke.xlsx'")

