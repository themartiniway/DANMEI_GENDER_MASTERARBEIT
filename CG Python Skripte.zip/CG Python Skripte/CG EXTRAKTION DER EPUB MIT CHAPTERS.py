import os
import zipfile
import bs4  # BeautifulSoup für HTML-Parsing
import pandas as pd
import re  # Für reguläre Ausdrücke
from fuzzywuzzy import process  # Unscharfe Textsuche verbessern

# Pfade und Ordner festlegen
epub_folder = "/Users/martinaschorsten/PycharmProjects/DanmeiMA/epub_werke"  #  Ordner mit EPUBs
output_folder = "extrahierte_kapitel"  # Zielordner für gespeicherte Kapitel
excel_path = "finale_werke.xlsx"  #  Tabelle mit Kapiteln

# Ausgabeordner soll existieren
os.makedirs(output_folder, exist_ok=True)

# Excel-Datei mit den ausgwählten Werken & Kapitel laden
df = pd.read_excel(excel_path)

# Liste der EPUB-Dateien im Ordner aufnehmen
epub_files = [f for f in os.listdir(epub_folder) if f.endswith(".epub")]

# Funktion zur besten Namensübereinstimmung zwischen Tabelle & Datei,
# da die Dateiennamen immer ein bisschen anders sein
def find_best_match(work_name, file_list):
    match, score = process.extractOne(work_name, file_list)  # Höchste Übereinstimmung suchen
    return match if score > 80 else None  # Nur akzeptieren, wenn die Übereinstimmung hoch genug ist

#  Alle Werke mit den passenden EPUB-Dateien verknüpfen
mapping = {}
for work_name in df["name"]:  # Name des Werks aus der Tabelle
    best_match = find_best_match(work_name, epub_files)
    if best_match:
        mapping[work_name] = best_match  # Verknüpfen: Werksname → EPUB-Datei

# Funktion zum Extrahieren von Text aus einem EPUB-Kapitel
# EPUBs sind speziell aufgebaute HTML-Texte
def extract_text_from_epub(epub_path, chapter_file):
    with zipfile.ZipFile(epub_path, "r") as epub:
        with epub.open(chapter_file) as file:
            soup = bs4.BeautifulSoup(file.read(), "html.parser")
            return soup.get_text(separator="\n")  # Extrahierter Text

#  Funktion zur automatischen Identifikation von Kapitelnamen
def identify_chapter_name(chapter_text):
    patterns = [
        # Was als Kapitel erkannt wird
        r"(?:Chapter|Kapitel|Ch)\s*(\d+)",  # "Chapter 14" oder "Ch14"
        r"\b(\d{1,3})\b"  # Isolierte Zahl (z. B. "42" alleinstehend)
    ]

    for pattern in patterns:
        match = re.search(pattern, chapter_text, re.IGNORECASE)
        if match:
            return int(match.group(1))  # Nummer extrahieren

    return None  # Falls keine Kapitelnummer gefunden wurde

#  EPUBs durchgehen & Kapitel extrahieren
for werk_name, epub_file in mapping.items():
    epub_path = os.path.join(epub_folder, epub_file)

    # ePUB entpacken & Kapiteldateien suchen
    with zipfile.ZipFile(epub_path, "r") as epub:
        file_list = epub.namelist()
        chapter_files = [f for f in file_list if f.endswith(".xhtml") or f.endswith(".html")]

    # Kapitel-Nummern für dieses Werk aus der Tabelle holen
    try:
        kapitel_liste = eval(df[df["name"] == werk_name]["zu annotierende kapitel"].values[0])  # Liste extrahieren
    except:
        print(f"Fehler!  {werk_name} ? Später anschauen.")
        continue

    # Kapitel extrahieren & speichern
    for chapter_file in chapter_files:
        chapter_text = extract_text_from_epub(epub_path, chapter_file)
        extracted_chapter_num = identify_chapter_name(chapter_text)

        if extracted_chapter_num in kapitel_liste:
            txt_filename = f"{output_folder}/{werk_name}_Kapitel_{extracted_chapter_num}.txt"
            with open(txt_filename, "w", encoding="utf-8") as txt_file:
                txt_file.write(chapter_text)

# Signal, um Ende und Erfolg zu zeigen
            print(f"Kapitel {extracted_chapter_num} aus '{werk_name}' gespeichert als {txt_filename}")
