import os
import zipfile
import bs4  # BeautifulSoup für HTML-Parsing

# Ordner erstellen
epub_folder = "/Users/martinaschorsten/PycharmProjects/DanmeiMA/epub_werke"  # Ordner mit EPUBs
output_folder = "epub_als_txt"  # Zielordner für die gespeicherten Txt-Dateien

# Sicherstellen, dass der Ausgabeordner existiert
# Vermeidung von Fehlermeldungen
os.makedirs(output_folder, exist_ok=True)

# Funktion zum Extrahieren von reinem Text aus einer EPUB-Datei durch html
def extract_text_from_epub(epub_path):
    full_text = []

    with zipfile.ZipFile(epub_path, "r") as epub:
        file_list = epub.namelist()
        chapter_files = [f for f in file_list if f.endswith(".xhtml") or f.endswith(".html")]

        for chapter_file in chapter_files:
            with epub.open(chapter_file) as file:
                soup = bs4.BeautifulSoup(file.read(), "html.parser")
                full_text.append(soup.get_text(separator="\n"))  # Kapiteltext selbst extrahieren

    return "\n".join(full_text)  # Alle Kapitel zusammenfügen in einer Datei

# EPUBs durchsuchen und umwandeln
for epub_file in os.listdir(epub_folder):
    if epub_file.endswith(".epub"):
        epub_path = os.path.join(epub_folder, epub_file)

        # Werkname aus Dateinamen extrahieren (ohne .epub)
        werk_name = os.path.splitext(epub_file)[0]

        print(f"Verarbeite: {werk_name}...")

        # Text extrahieren
        full_text = extract_text_from_epub(epub_path)

        # Speichern als TXT-Datei
        txt_filename = os.path.join(output_folder, f"{werk_name}.txt")
        with open(txt_filename, "w", encoding="utf-8") as txt_file:
            txt_file.write(full_text)

        print(f"DONE! : {txt_filename}")

print("\nGeschafft !")
